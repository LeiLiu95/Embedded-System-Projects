#include "../inc/tm4c123gh6pm.h"

void switch_Init();
void play_pause(void);
void rewind_button(void);
void tempo_Change(void);
void check_song(void);