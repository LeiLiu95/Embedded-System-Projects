#include <stdint.h>

void dac_init(uint16_t data);

void DAC_Out(uint16_t data);