#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"

extern struct Song song;

void init_Song(void);

void reset(void);

void Timer0A_Init100HzInt(void);

void play_note(void);

#define sixteenth 1
#define eight 2
#define quarter	4
#define half	8
#define whole 16

#define C_2 11945   // 65.406 Hz
#define DF_1 11274   // 69.296 Hz
#define D_1 10641   // 73.416 Hz
#define EF_1 10044   // 77.782 Hz
#define E_1 9480   // 82.407 Hz
#define F_1 8948   // 87.307 Hz
#define GF_1 8446   // 92.499 Hz
#define G_1 7972   // 97.999 Hz
#define AF_1 7525   // 103.826 Hz
#define A_1 7102   // 110.000 Hz
#define BF_1 6704   // 116.541 Hz
#define B_1 6327   // 123.471 Hz
#define C_1 5972   // 130.813 Hz
#define DF0 5637   // 138.591 Hz
#define D0 5321   // 146.832 Hz
#define EF0 5022   // 155.563 Hz
#define E0 4740   // 164.814 Hz
#define F0 4474   // 174.614 Hz
#define GF0 4223   // 184.997 Hz
#define G0 3986   // 195.998 Hz
#define AF0 3762   // 207.652 Hz
#define A0 3551   // 220.000 Hz
#define BF0 3352   // 233.082 Hz
#define B0 3164   // 246.942 Hz
#define C0 2986   // 261.626 Hz
#define DF 2819   // 277.183 Hz
#define D 2660   // 293.665 Hz
#define EF 2511   // 311.127 Hz
#define E 2370   // 329.628 Hz
#define F 2237   // 349.228 Hz
#define GF 2112   // 369.994 Hz
#define G 1993   // 391.995 Hz
#define AF 1881   // 415.305 Hz
#define A 1776   // 440.000 Hz
#define BF 1676   // 466.164 Hz
#define B 1582   // 493.883 Hz
#define C 1493   // 523.251 Hz
#define DF1 1409   // 554.365 Hz
#define D1 1330   // 587.330 Hz
#define EF1 1256   // 622.254 Hz
#define E1 1185   // 659.255 Hz
#define F1 1119   // 698.456 Hz
#define GF1 1056   // 739.989 Hz
#define G1 997   // 783.991 Hz
#define AF1 941   // 830.609 Hz
#define A1 888   // 880.000 Hz
#define BF1 838   // 932.328 Hz
#define B1 791   // 987.767 Hz
#define C1 747   // 1046.502 Hz
#define DF2 705   // 1108.731 Hz
#define D2 665   // 1174.659 Hz
#define EF2 628   // 1244.508 Hz
#define E2 593   // 1318.510 Hz
#define F2 559   // 1396.913 Hz
#define GF2 528   // 1479.978 Hz
#define G2 498   // 1567.982 Hz
#define AF2 470   // 1661.219 Hz
#define A2 444   // 1760.000 Hz
#define BF2 419   // 1864.655 Hz
#define B2 395   // 1975.533 Hz
#define C2 373   // 2093.005 Hz


/*#define C_2 65	//11945
#define DF_1 69	//11274
#define D_1 73	10641
#define EF_1 78	//10044
#define E_1 82	//9480
#define F_1 87	//8948
#define GF_1 92	//8446
#define G_1 98	//7972
#define AF_1 104	//7525
#define A_1 110	//7102
#define BF_1 117	//6704
#define B_1 123		//6327
#define C_1 131	//5972
#define DF0 139	//5637
#define D0 147	//5321
#define EF0 156	//5022
#define E0 165	//4740
#define F0 175	//4474
#define GF0 185	//4223
#define G0 196	//3986
#define AF0 208	//3762
#define A0 220	//3551
#define BF0 233	//3352
#define B0 247	//3164
#define C0 262	//2986
#define DF 277	//2819
#define D 294	//2660
#define EF 311	//2511
#define E 330	//2370
#define F 349	//2237
#define GF 370	//2112
#define G 392	//1993
#define AF 415	//1881
#define A 440	//1776
#define BF 466	//1676
#define B 494	//1582
#define C 523	//1493
#define DF1 554	//1409
#define D1 587	//1330
#define EF1 622	//1256
#define E1 659	//1185
#define F1 698	//1119
#define GF1 740	//1056
#define G1 784	//997
#define AF1 830	//941
#define A1 880	//888
#define BF1 932	//838
#define B1 988	//791
#define C1 1047	//747
#define DF2 1109	//705
#define D2 1175	//665
#define EF2 1245	//628
#define E2 1319	//593
#define F2 1397	//559
#define GF2 1480	//528
#define G2 1568	//498
#define AF2 1661	//470
#define A2 1760	//444
#define BF2 1865	//419
#define B2 1975	//395
#define C2 2093	//373
*/
